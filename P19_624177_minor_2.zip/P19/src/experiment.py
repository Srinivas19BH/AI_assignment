"""Run reproducible P19 experiments and save CSV + Gantt charts."""
import argparse, csv, sys, time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from starter.jobshop import generate_instance, lower_bound, check_official
from src.agents import spt, mwkr, branch_and_bound, local_search, best_dispatch
from src.env import check_schedule

def gantt(jobs,schedule,path,title):
    fig,ax=plt.subplots(figsize=(10,5))
    for j,job in enumerate(jobs):
        for k,(m,d) in enumerate(job):
            st=schedule["start"][(j,k)]
            ax.barh(m,d,left=st,edgecolor="black",alpha=.75)
            ax.text(st+d/2,m,f"J{j+1}-O{k+1}",ha="center",va="center",fontsize=7)
    ax.set_xlabel("Time"); ax.set_ylabel("Machine"); ax.set_yticks(sorted({m for job in jobs for m,_ in job}))
    ax.set_title(title); ax.grid(axis="x",alpha=.25); fig.tight_layout()
    path.parent.mkdir(parents=True,exist_ok=True); fig.savefig(path,dpi=150); plt.close(fig)

def main():
    p=argparse.ArgumentParser()
    p.add_argument("--seeds",nargs="+",type=int,default=[0,1,2])
    p.add_argument("--size",type=int,default=6)
    p.add_argument("--time-limit",type=float,default=5)
    p.add_argument("--node-limit",type=int,default=2000000)
    a=p.parse_args()
    out=ROOT/"results"; (out/"figures").mkdir(parents=True,exist_ok=True)
    rows=[]
    for seed in a.seeds:
        jobs=generate_instance(a.size,a.size,seed)
        lb=lower_bound(jobs,a.size)
        methods=[]
        def timed(name,fn):
            t=time.time(); r=fn(); r["seconds"]=time.time()-t; methods.append((name,r)); return r
        a1=timed("SPT",lambda:spt(jobs)); a2=timed("MWKR",lambda:mwkr(jobs))
        timed("BranchAndBound",lambda:branch_and_bound(jobs,a.time_limit,a.node_limit))
        init=min((a1,a2),key=lambda x:x["makespan"])
        timed("LocalSearch",lambda:local_search(jobs,init))
        for name,s in methods:
            ok,errors=check_schedule(jobs,s)
            if check_official(jobs,s["start"])!=s["makespan"]: raise RuntimeError(f"official checker disagrees: {name}, seed {seed}")
            if not ok: raise RuntimeError(f"{name} invalid for seed {seed}: {errors}")
            rows.append({"method":name,"seed":seed,"size":a.size,"makespan":s["makespan"],
                         "lower_bound":lb,"gap_to_lower_bound":s["makespan"]-lb,
                         "nodes":s.get("nodes",s.get("evaluations",0)),
                         "seconds":round(s.get("seconds",0),4),
                         "optimality_proved":s.get("optimality_proved",False)})
            gantt(jobs,s,out/"figures"/f"seed{seed}_{name}.png",f"Seed {seed} — {name} — makespan {s['makespan']}")
        print(f"seed={seed}: LB={lb}, "+", ".join(f"{n}={s['makespan']}" for n,s in methods))
    with (out/"metrics.csv").open("w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    print(f"\nSaved {out/'metrics.csv'} and Gantt charts in {out/'figures'}")

if __name__=="__main__": main()
