"""Job-shop schedule representation, decoding and validation."""
from collections import defaultdict, deque


def validate_jobs(jobs):
    if not jobs:
        raise ValueError("At least one job is required")
    machines = [m for job in jobs for m, d in job]
    if not machines or min(machines) < 0:
        raise ValueError("Machine IDs must be non-negative")
    if any(d <= 0 for job in jobs for _, d in job):
        raise ValueError("Processing times must be positive")


def decode_machine_orders(jobs, machine_orders):
    """Earliest-start schedule for fixed machine sequences (DAG longest path).

    Returns None if the machine orders create a cycle (infeasible)."""
    ops = [(j, k) for j, job in enumerate(jobs) for k in range(len(job))]
    succ = defaultdict(list)
    preds = defaultdict(list)
    indeg = {op: 0 for op in ops}
    for j, job in enumerate(jobs):
        for k in range(len(job) - 1):
            a, b = (j, k), (j, k + 1)
            succ[a].append(b); preds[b].append(a); indeg[b] += 1
    for order in machine_orders.values():
        for a, b in zip(order, order[1:]):
            succ[a].append(b); preds[b].append(a); indeg[b] += 1
    q = deque(op for op in ops if indeg[op] == 0)
    start, finish = {}, {}
    while q:
        op = q.popleft()
        j, k = op
        d = jobs[j][k][1]
        st = max((finish[p] for p in preds[op]), default=0)
        start[op] = st
        finish[op] = st + d
        for nxt in succ[op]:
            indeg[nxt] -= 1
            if indeg[nxt] == 0:
                q.append(nxt)
    if len(start) != len(ops):
        return None  # cycle in the disjunctive graph
    return {"start": start, "finish": finish,
            "makespan": max(finish.values(), default=0)}


def machine_orders_from_schedule(jobs, schedule):
    by_machine = defaultdict(list)
    for j, job in enumerate(jobs):
        for k, (m, _) in enumerate(job):
            by_machine[m].append((j, k))
    for m in by_machine:
        by_machine[m].sort(key=lambda op: (schedule["start"][op], schedule["finish"][op]))
    return dict(by_machine)


def critical_path(jobs, schedule):
    """One critical path (list of ops, first to last) of a semi-active schedule."""
    orders = machine_orders_from_schedule(jobs, schedule)
    mpred = {}
    for order in orders.values():
        for a, b in zip(order, order[1:]):
            mpred[b] = a
    fin, st = schedule["finish"], schedule["start"]
    op = max(fin, key=lambda o: fin[o])
    path = [op]
    while st[op] > 0:
        j, k = op
        nxt = None
        if op in mpred and fin[mpred[op]] == st[op]:
            nxt = mpred[op]
        elif k > 0 and fin[(j, k - 1)] == st[op]:
            nxt = (j, k - 1)
        if nxt is None:
            break
        path.append(nxt); op = nxt
    return path[::-1]


def check_schedule(jobs, schedule):
    if schedule is None:
        return False, ["No feasible schedule (cycle or missing operations)"]
    errors = []
    for j, job in enumerate(jobs):
        for k in range(len(job) - 1):
            a, b = (j, k), (j, k + 1)
            if schedule["finish"][a] > schedule["start"][b]:
                errors.append(f"Precedence violation: {a} before {b}")
    by_machine = defaultdict(list)
    for j, job in enumerate(jobs):
        for k, (m, d) in enumerate(job):
            op = (j, k)
            if op not in schedule["start"] or op not in schedule["finish"]:
                errors.append(f"Missing operation {op}")
            else:
                if schedule["finish"][op] - schedule["start"][op] != d:
                    errors.append(f"Wrong duration for {op}")
                by_machine[m].append(op)
    for m, ops in by_machine.items():
        ops.sort(key=lambda op: schedule["start"][op])
        for a, b in zip(ops, ops[1:]):
            if schedule["finish"][a] > schedule["start"][b]:
                errors.append(f"Machine {m} overlap: {a} and {b}")
    mk = max(schedule["finish"].values(), default=0)
    if schedule.get("makespan", mk) != mk:
        errors.append("Reported makespan does not match schedule")
    return not errors, errors


def schedule_from_machine_orders(jobs, orders):
    return decode_machine_orders(jobs, orders)
