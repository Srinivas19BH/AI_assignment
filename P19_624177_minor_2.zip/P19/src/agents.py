"""Non-delay dispatching rules (SPT, MWKR), branch-and-bound over
Giffler-Thompson conflict sets (active schedules, which always include an
optimum), and critical-path local search."""
import time
from collections import defaultdict
from .env import (machine_orders_from_schedule, decode_machine_orders,
                  critical_path)


def _nondelay_schedule(jobs, rule):
    """Non-delay dispatching: always schedule an operation that can start at the
    earliest possible time; ties among those are broken by the priority rule."""
    n = len(jobs)
    next_op = [0] * n
    job_ready = [0] * n
    machine_ready = defaultdict(int)
    start, finish = {}, {}
    total = sum(len(x) for x in jobs)
    for _ in range(total):
        cands = [(max(job_ready[j], machine_ready[jobs[j][next_op[j]][0]]), j)
                 for j in range(n) if next_op[j] < len(jobs[j])]
        earliest = min(s for s, _ in cands)
        tied = [j for s, j in cands if s == earliest]
        if rule == "SPT":
            j = min(tied, key=lambda x: (jobs[x][next_op[x]][1], x))
        elif rule == "MWKR":
            j = max(tied, key=lambda x: (sum(d for _, d in jobs[x][next_op[x]:]), -x))
        else:
            raise ValueError(rule)
        k = next_op[j]
        m, d = jobs[j][k]
        st = max(job_ready[j], machine_ready[m])
        start[(j, k)] = st; finish[(j, k)] = st + d
        job_ready[j] = machine_ready[m] = st + d
        next_op[j] += 1
    return {"start": start, "finish": finish,
            "makespan": max(finish.values(), default=0), "nodes": total}


def spt(jobs):
    return _nondelay_schedule(jobs, "SPT")


def mwkr(jobs):
    return _nondelay_schedule(jobs, "MWKR")


def best_dispatch(jobs):
    return min((spt(jobs), mwkr(jobs)), key=lambda x: x["makespan"])


def branch_and_bound(jobs, time_limit=5.0, node_limit=500000):
    """Depth-first B&B over Giffler-Thompson conflict sets.

    At each node, the machine m* with the earliest possible completion time c*
    is found; we branch on every operation on m* that could start before c*.
    This enumerates all active schedules, so it is exact if it finishes.
    Pruning uses a job + machine lower bound and the best incumbent
    (initialised from the better dispatching rule).
    `optimality_proved` is True only if the search ended without a limit.
    """
    n = len(jobs)
    total = sum(map(len, jobs))
    best = dict(best_dispatch(jobs))
    next_op = [0] * n
    job_ready = [0] * n
    machine_ready = defaultdict(int)
    st, fn = {}, {}
    t0 = time.time()
    nodes = 0
    stopped = False
    n_mach = 1 + max(m for job in jobs for m, _ in job)
    # suffix[j][k] = sum of durations of ops k.. of job j
    suffix = [[sum(d for _, d in job[k:]) for k in range(len(job) + 1)] for job in jobs]

    def lower_bound(cur_max):
        lb = cur_max
        mach_head = [None] * n_mach
        mach_work = [0] * n_mach
        for j in range(n):
            head = job_ready[j]
            for k in range(next_op[j], len(jobs[j])):
                m, d = jobs[j][k]
                mach_work[m] += d
                if mach_head[m] is None or head < mach_head[m]:
                    mach_head[m] = head
                head += d
            lb = max(lb, job_ready[j] + suffix[j][next_op[j]])
        for m in range(n_mach):
            if mach_head[m] is not None:
                lb = max(lb, max(mach_head[m], machine_ready[m]) + mach_work[m])
        return lb

    def dfs(cur_max, done):
        nonlocal best, nodes, stopped
        if stopped:
            return
        if nodes >= node_limit or time.time() - t0 >= time_limit:
            stopped = True
            return
        nodes += 1
        if done == total:
            if cur_max < best["makespan"]:
                best = {"start": dict(st), "finish": dict(fn), "makespan": cur_max}
            return
        if lower_bound(cur_max) >= best["makespan"]:
            return
        c_star, m_star = None, None
        for j in range(n):
            k = next_op[j]
            if k < len(jobs[j]):
                m, d = jobs[j][k]
                c = max(job_ready[j], machine_ready[m]) + d
                if c_star is None or c < c_star:
                    c_star, m_star = c, m
        conflict = []
        for j in range(n):
            k = next_op[j]
            if k < len(jobs[j]) and jobs[j][k][0] == m_star:
                s = max(job_ready[j], machine_ready[m_star])
                if s < c_star:
                    conflict.append((s + jobs[j][k][1], j))
        conflict.sort()
        for _, j in conflict:
            k = next_op[j]
            m, d = jobs[j][k]
            s = max(job_ready[j], machine_ready[m])
            old_j, old_m = job_ready[j], machine_ready[m]
            next_op[j] += 1; job_ready[j] = s + d; machine_ready[m] = s + d
            st[(j, k)] = s; fn[(j, k)] = s + d
            dfs(max(cur_max, s + d), done + 1)
            del st[(j, k)]; del fn[(j, k)]
            next_op[j] -= 1; job_ready[j] = old_j; machine_ready[m] = old_m
            if stopped:
                return

    dfs(0, 0)
    best["nodes"] = nodes
    best["optimality_proved"] = not stopped
    best["seconds"] = time.time() - t0
    return best


def local_search(jobs, initial=None, max_passes=1000):
    """Critical-path adjacent-swap local search (first improvement).

    Only adjacent operations on the same machine that lie consecutively on a
    critical path are swapped (the N1-style neighbourhood); infeasible
    (cyclic) swaps are rejected by the decoder. Stops at a local optimum."""
    if initial is None:
        initial = best_dispatch(jobs)
    orders = machine_orders_from_schedule(jobs, initial)
    best = decode_machine_orders(jobs, orders)
    if best is None:
        return initial
    evaluations = 0
    for _ in range(max_passes):
        path = critical_path(jobs, best)
        improved = False
        for a, b in zip(path, path[1:]):
            ma, mb = jobs[a[0]][a[1]][0], jobs[b[0]][b[1]][0]
            if ma != mb:
                continue
            order = orders[ma]
            i = order.index(a)
            if i + 1 >= len(order) or order[i + 1] != b:
                continue
            cand = {m: list(v) for m, v in orders.items()}
            cand[ma][i], cand[ma][i + 1] = b, a
            sched = decode_machine_orders(jobs, cand)
            evaluations += 1
            if sched is not None and sched["makespan"] < best["makespan"]:
                orders, best, improved = cand, sched, True
                break
        if not improved:
            break
    best["evaluations"] = evaluations
    best["nodes"] = evaluations
    return best
