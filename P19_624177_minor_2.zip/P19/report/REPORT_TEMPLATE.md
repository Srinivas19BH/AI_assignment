# P19 Job-Shop Scheduling — Report template

## 1. Problem formulation
Describe jobs, operations, machines, precedence constraints, machine exclusivity,
and makespan objective.

## 2. Methods
Describe SPT, MWKR, Branch and Bound, and critical-machine adjacent-swap local search.
State any node/time limits.

## 3. Experimental setup
List Python version, CPU, instance size, seeds, and exact command used.

## 4. Results
Insert the measured rows from `results/metrics.csv`. Include Gantt charts.
Report makespan minus lower bound as a gap to the lower bound. Do not call it
an optimality gap unless Branch and Bound proved optimality.

## 5. Analysis and limitations
Explain which method performed best, runtime/search effort, and why results differ.
Clearly state whether the official faculty starter instances were used.

## 6. Correctness and reproducibility
Summarize unit tests and provide exact commands to reproduce the results.
