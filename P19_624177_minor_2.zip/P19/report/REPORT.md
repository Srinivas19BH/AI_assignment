# P19 Job-Shop Scheduling — Report

EC3161 Minor 2 project. Technique area: **search** (heuristic and exact search, local search).

## 1. Problem formulation

There are *n* jobs and *m* machines. Job *j* is an ordered list of operations
O(j,1), …, O(j,m); each operation needs one specific machine for a given processing
time. Constraints:

- **Precedence:** O(j,k+1) cannot start before O(j,k) finishes.
- **Machine exclusivity:** a machine processes at most one operation at a time; no pre-emption.

**Objective:** minimise the makespan C_max, the largest operation completion time.

Search view: a state is a partial schedule; an action appends the next operation of some
job; the goal is a complete schedule; the cost is the makespan.

**Lower bound** used for reporting: max(longest job workload, heaviest machine workload).

## 2. Methods

**Non-delay dispatching rules.** At each step, among the next operations of all unfinished
jobs, take those that can start earliest; break ties with a priority rule. 
- **SPT**: shortest processing time.
- **MWKR**: job with the most work remaining.

**Giffler–Thompson (GT) conflict sets** (used by branch and bound). Find the schedulable
operation with the earliest possible completion time c* and its machine m*. The *conflict set*
is the set of operations on m* that could start before c*. Branching over it generates all
*active* schedules, a set that always contains an optimal schedule.

**Branch and Bound (B&B).** Depth-first search branching on every operation in the
conflict set, so it enumerates all active schedules. A node is pruned when its lower bound
is at least the incumbent makespan. The bound is the maximum of: the current makespan,
each job's ready time plus remaining work, and for each machine
max(machine ready, earliest head of its remaining operations) + its remaining work.
The incumbent starts as the better of SPT and MWKR (non-delay). Children are tried in order of
earliest completion. A node limit (2,000,000) and a time limit are used; the result is
called optimal only if the search finished without hitting a limit.

**Local search.** Start from the better dispatching schedule, represented by one operation
order per machine. Compute a critical path; try swapping each pair of adjacent operations
that are consecutive on the critical path and on the same machine. The new order is decoded
by longest-path computation on the disjunctive graph (cyclic, infeasible swaps are rejected).
The first improving swap is accepted; the search stops at a local optimum.

## 3. Experimental setup

- Python 3.13, Intel Xeon 2.1 GHz, 2 cores, CPU only.
- Instances: the faculty's official starter (`starter/Starterjobshop.py`, unmodified), `instance(n, n, seed)`
  and its `lower_bound`. Every schedule is also checked with the faculty's `check` function.
- Reference check: SPT on 6×6 seed 0 gives makespan 63, matching the faculty reference value.
- 6×6: seeds 0–4, time limit 60 s. 10×10: seeds 0–2, time limit 20 s, node limit 2,000,000.
- Commands:
  `python src/experiment.py --seeds 0 1 2 3 4 --size 6 --time-limit 60`
  `python src/experiment.py --seeds 0 1 2 --size 10 --time-limit 20`

## 4. Results

### 6×6 (all measured; B&B proved optimality on every seed)

| Seed | LB | SPT | MWKR | B&B (optimal) | Local search | B&B nodes | B&B time (s) |
|---|---|---|---|---|---|---|---|
| 0 | 45 | 63 | 70 | 59 | 63 | 4,229 | 0.02 |
| 1 | 43 | 67 | 60 | 55 | 57 | 26,303 | 0.12 |
| 2 | 47 | 69 | 65 | 64 | 65 | 56,691 | 0.20 |
| 3 | 49 | 67 | 61 | 53 | 55 | 6,987 | 0.03 |
| 4 | 38 | 48 | 47 | 45 | 47 | 76,113 | 0.33 |
| **Avg** | | **62.8** | **60.6** | **55.2** | **57.4** | | |

Average gap to the lower bound: SPT 18.4, MWKR 16.2, B&B 10.8, local search 13.0. Because B&B
proved optimality, the remaining B&B gap reflects the weakness of the simple lower bound, not of B&B.

### 10×10 (B&B stopped at the node limit, so no optimality claim)

| Seed | LB | SPT | MWKR | B&B (best found) | Local search |
|---|---|---|---|---|---|
| 0 | 74 | 111 | 107 | 105 | 106 |
| 1 | 72 | 112 | 107 | 98 | 107 |
| 2 | 73 | 113 | 100 | 100 | 97 |
| **Avg** | | **112.0** | **104.7** | **101.0** | **103.3** |

Average gap to the lower bound: SPT 39.0, MWKR 31.7, B&B 28.0, local search 30.3.
Gantt charts: `results/figures_6x6/`, `results/figures_10x10/`. Raw data: `results/metrics_6x6.csv`,
`results/metrics_10x10.csv`.

## 5. Analysis and limitations

- **SPT is the weakest rule on average**; it ignores how much work a job still has. **MWKR** is
  better on average (60.6 vs 62.8 on 6×6; 104.7 vs 112.0 on 10×10) at essentially zero cost,
  but not on every instance (SPT wins on 6×6 seed 0).
- **On 6×6, B&B is best and exact** (average 55.2): the search space is small enough to finish
  in at most about 0.3 s. Local search from the better dispatching schedule reaches 57.4; it
  never beats B&B here and is at most 4 above it.
- **On 10×10, B&B does not finish** within 2,000,000 nodes (about 13 s). Its best found schedule is
  still best on average (101.0), but local search is competitive (103.3) in milliseconds and beats
  B&B on seed 2 (97 vs 100). Exact search scales poorly; local search is the practical choice for
  larger instances. Using local search to seed B&B is a natural improvement but was not
  implemented or measured.
- The lower bound is simple, so "gap to lower bound" is an optimality gap only where B&B proved
  optimality (all 6×6 runs).
- Only a few seeds were run, so the averages are indicative, not statistically conclusive.
  Only SPT on 6×6 seed 0 (63) was checked against a faculty reference value; other reference
  values were not available to us.

## 6. Correctness and reproducibility

`check_schedule` (ours) and the faculty's `check` verify precedence, machine overlap, operation
durations and makespan for every schedule produced by every method in every run (the experiment aborts otherwise).
Unit tests (`python -m unittest discover -s tests -v`, 6 tests) cover: validity of
dispatching and local-search schedules, a tiny instance with known optimum 4 (checked by
brute force), cycle detection in the decoder, B&B equal to brute-force optimum on 3×3
instances, and the lower bound never exceeding the true optimum.

## AI-use statement

*(Fill in honestly: which AI tools you used and for what, and what you personally ran,
checked, modified and understood.)*
