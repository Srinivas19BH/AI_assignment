import itertools
import sys
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from starter.jobshop import generate_instance, lower_bound
from src.agents import spt, mwkr, local_search, branch_and_bound, best_dispatch
from src.env import check_schedule, decode_machine_orders


def brute_force_optimum(jobs):
    """Exhaustive search over all machine permutations (tiny instances only)."""
    by_m = {}
    for j, job in enumerate(jobs):
        for k, (m, _) in enumerate(job):
            by_m.setdefault(m, []).append((j, k))
    ms = sorted(by_m)
    best = None
    for perms in itertools.product(*[itertools.permutations(by_m[m]) for m in ms]):
        s = decode_machine_orders(jobs, {m: list(p) for m, p in zip(ms, perms)})
        if s is not None and (best is None or s["makespan"] < best):
            best = s["makespan"]
    return best


class JobShopTests(unittest.TestCase):
    def test_dispatch_rules_valid(self):
        for seed in range(5):
            jobs = generate_instance(6, 6, seed)
            for sched in (spt(jobs), mwkr(jobs)):
                self.assertTrue(check_schedule(jobs, sched)[0])

    def test_local_search_valid_and_not_worse(self):
        for seed in range(5):
            jobs = generate_instance(5, 5, seed)
            initial = best_dispatch(jobs)
            result = local_search(jobs, initial)
            self.assertTrue(check_schedule(jobs, result)[0])
            self.assertLessEqual(result["makespan"], initial["makespan"])

    def test_tiny_known_optimum(self):
        # Machine 0 carries 2+2 = 4 units of work, so 4 is optimal.
        jobs = [[(0, 2), (1, 1)], [(1, 1), (0, 2)]]
        orders = {0: [(0, 0), (1, 1)], 1: [(1, 0), (0, 1)]}
        s = decode_machine_orders(jobs, orders)
        self.assertEqual(s["makespan"], 4)
        self.assertTrue(check_schedule(jobs, s)[0])
        self.assertEqual(brute_force_optimum(jobs), 4)

    def test_decoder_detects_cycle(self):
        jobs = [[(0, 1), (1, 1)], [(1, 1), (0, 1)]]
        # M0: J2 before J1, M1: J1 before J2 -> circular wait
        orders = {0: [(1, 1), (0, 0)], 1: [(0, 1), (1, 0)]}
        self.assertIsNone(decode_machine_orders(jobs, orders))

    def test_bnb_matches_brute_force(self):
        for seed in range(4):
            jobs = generate_instance(3, 3, seed)
            result = branch_and_bound(jobs, time_limit=20, node_limit=10**7)
            self.assertTrue(check_schedule(jobs, result)[0])
            self.assertTrue(result["optimality_proved"])
            self.assertEqual(result["makespan"], brute_force_optimum(jobs))

    def test_lower_bound_is_valid(self):
        for seed in range(4):
            jobs = generate_instance(3, 3, seed)
            self.assertLessEqual(lower_bound(jobs, 3), brute_force_optimum(jobs))


if __name__ == "__main__":
    unittest.main()
