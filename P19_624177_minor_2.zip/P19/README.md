# EC3161 Mini Project P19 — Job-Shop Scheduling

A CPU-only Python project that minimises **makespan** in the job-shop scheduling
problem using search techniques from the AI course:

- **SPT** and **MWKR** non-delay dispatching rules
- **Branch and Bound** over Giffler–Thompson conflict sets (exact if it finishes)
- **Critical-path adjacent-swap local search**

> **Instances:** `starter/Starterjobshop.py` is the faculty's official starter, kept
> unmodified. `starter/jobshop.py` is a thin adapter around it, so instances, seeds and
> the lower bound are the official ones.

## Problem

Each job is an ordered list of operations `(machine, processing_time)`. Operations of
a job run in order; a machine runs one operation at a time. Objective: minimise the
makespan (time the last operation finishes).

## Run

Python 3.10+; only `matplotlib` is needed (for Gantt charts).

```bash
pip install -r requirements.txt
python -m unittest discover -s tests -v
python src/experiment.py --seeds 0 1 2 3 4 --size 6 --time-limit 60
python src/experiment.py --seeds 0 1 2 --size 10 --time-limit 20
```

Each run writes `results/metrics.csv` and Gantt charts in `results/figures/`
(it overwrites the previous run; the committed `metrics_6x6.csv`, `metrics_10x10.csv`
and `figures_*` folders are copies of the runs reported in `report/REPORT.md`).

## Layout

```
src/env.py         schedule decoding, critical path, validity checker
src/agents.py      SPT, MWKR, branch and bound, local search
src/experiment.py  experiment runner (CSV + Gantt charts)
starter/jobshop.py instance generator and lower bound
tests/             unit tests (validity, cycle detection, brute-force optimum)
report/REPORT.md   project report
slides/            presentation
```

## Results summary (seeds in report)

| Size | Method | Avg makespan | Avg gap to lower bound |
|---|---|---|---|
| 6×6 (5 seeds) | SPT | 62.8 | 18.4 |
| 6×6 | MWKR | 60.6 | 16.2 |
| 6×6 | Branch and Bound (optimal on all 5) | 55.2 | 10.8 |
| 6×6 | Local search | 57.4 | 13.0 |
| 10×10 (3 seeds) | SPT | 112.0 | 39.0 |
| 10×10 | MWKR | 104.7 | 31.7 |
| 10×10 | Branch and Bound (limit hit, not proved) | 101.0 | 28.0 |
| 10×10 | Local search | 103.3 | 30.3 |

SPT on seed 0 (6×6) gives makespan 63, matching the faculty reference value.
"Gap to lower bound" = makespan − lower bound. It is an optimality gap only where
branch and bound proved optimality (all 6×6 runs).

## Correctness

Every schedule from every method is checked by our `check_schedule` and by the faculty's
`check` function (precedence, machine overlap, durations, makespan). Tests also compare branch and bound with brute force on
3×3 instances and check that cyclic machine orders are rejected.

## AI-use statement

*(Fill in honestly before submitting: which AI tools you used, for what, and what you
personally ran, checked and understood.)*
