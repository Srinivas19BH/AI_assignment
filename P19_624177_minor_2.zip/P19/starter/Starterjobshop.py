"""P19 starter: job-shop scheduling. Each job is a fixed sequence of (machine, duration) operations;
each machine processes one operation at a time. Objective: minimise makespan."""
import random

def instance(n_jobs=6, n_machines=6, seed=0):
    rng = random.Random(seed)
    return [[(m, rng.randint(1, 10)) for m in rng.sample(range(n_machines), n_machines)] for _ in range(n_jobs)]

def lower_bound(J):
    """max(longest job, busiest machine): no schedule can beat this."""
    machines = {m for job in J for m, _ in job}
    return max(max(sum(d for _, d in job) for job in J),
               max(sum(d for job in J for mm, d in job if mm == m) for m in machines))

def check(J, start):
    """start[(j, k)] = start time of operation k of job j. Returns makespan, or raises on a violation."""
    for j, job in enumerate(J):
        for k in range(1, len(job)):
            assert start[(j, k)] >= start[(j, k - 1)] + job[k - 1][1], f"precedence violated in job {j}"
    ops = [(job[k][0], start[(j, k)], start[(j, k)] + job[k][1]) for j, job in enumerate(J) for k in range(len(job))]
    for (m1, s1, e1), (m2, s2, e2) in ((a, b) for i, a in enumerate(ops) for b in ops[i + 1:]):
        assert m1 != m2 or e1 <= s2 or e2 <= s1, f"machine {m1} double-booked"
    return max(e for _, _, e in ops)

# TODO (students): dispatching rules (SPT, MWKR), CSP formulation with disjunctive constraints,
#                  backtracking / branch-and-bound on the makespan, local search on operation order.
if __name__ == "__main__":
    for s in range(3):
        print("seed", s, "lower bound", lower_bound(instance(seed=s)))
