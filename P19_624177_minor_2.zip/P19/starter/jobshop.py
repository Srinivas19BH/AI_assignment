"""Adapter around the faculty's official starter (starter/Starterjobshop.py, unmodified).

Keeps the names used by src/ and tests/. Instances and the lower bound are the
official ones; `check_official` is the faculty's own validity checker."""
from .Starterjobshop import instance, lower_bound as _official_lb, check as check_official


def generate_instance(n_jobs=6, n_machines=6, seed=0):
    return instance(n_jobs, n_machines, seed)


def lower_bound(jobs, n_machines=None):
    return _official_lb(jobs)
