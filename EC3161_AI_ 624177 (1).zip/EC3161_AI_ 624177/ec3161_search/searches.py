"""Uninformed search algorithms following EC-3161 conventions C1-C4."""

from __future__ import annotations

import heapq
from collections import deque
from dataclasses import dataclass
from typing import Any, Optional

from .core import Node, expand


@dataclass
class Stats:
    """Search statistics required by the assignment."""

    generated: int = 0
    expanded: int = 0
    max_frontier: int = 0
    max_reached: int = 0

    def as_dict(self) -> dict[str, int]:
        """Return the statistics as a plain dictionary."""
        return {
            "nodes_generated": self.generated,
            "nodes_expanded": self.expanded,
            "max_frontier_size": self.max_frontier,
            "max_reached_size": self.max_reached,
        }


def bfs(problem: Any) -> tuple[Optional[Node], dict[str, int]]:
    """Run BFS graph search with global reached, generation-time goal test."""
    root = Node(problem.initial_state())
    frontier = deque([root])
    reached = {root.state}
    stats = Stats(generated=1, max_frontier=1, max_reached=1)

    while frontier:
        node = frontier.popleft()
        stats.expanded += 1
        for child in expand(problem, node):
            stats.generated += 1
            if problem.goal_test(child.state):
                return child, stats.as_dict()
            if child.state not in reached:
                reached.add(child.state)
                frontier.append(child)
            stats.max_frontier = max(stats.max_frontier, len(frontier))
            stats.max_reached = max(stats.max_reached, len(reached))
    return None, stats.as_dict()


def ucs(problem: Any) -> tuple[Optional[Node], dict[str, int]]:
    """Run UCS graph search with best-g re-openings and stale-entry discard."""
    root = Node(problem.initial_state())
    counter = 0
    heap: list[tuple[float, int, Node]] = [(0.0, counter, root)]
    reached: dict[Any, float] = {root.state: 0.0}
    stats = Stats(generated=1, max_frontier=1, max_reached=1)

    while heap:
        g, _, node = heapq.heappop(heap)
        if g > reached[node.state]:
            continue
        if problem.goal_test(node.state):
            return node, stats.as_dict()
        stats.expanded += 1
        for child in expand(problem, node):
            stats.generated += 1
            old = reached.get(child.state)
            if old is None or child.path_cost < old:
                reached[child.state] = child.path_cost
                counter += 1
                heapq.heappush(heap, (child.path_cost, counter, child))
            stats.max_frontier = max(stats.max_frontier, len(heap))
            stats.max_reached = max(stats.max_reached, len(reached))
    return None, stats.as_dict()


def ucs_broken_no_reopen(problem: Any) -> tuple[Optional[Node], dict[str, int], list[tuple[Any, float, float]]]:
    """Deliberately broken UCS that never re-opens an already reached state."""
    root = Node(problem.initial_state())
    counter = 0
    heap: list[tuple[float, int, Node]] = [(0.0, counter, root)]
    reached: dict[Any, float] = {root.state: 0.0}
    stats = Stats(generated=1, max_frontier=1, max_reached=1)
    reopenings: list[tuple[Any, float, float]] = []

    while heap:
        g, _, node = heapq.heappop(heap)
        if g > reached[node.state]:
            continue
        if problem.goal_test(node.state):
            return node, stats.as_dict(), reopenings
        stats.expanded += 1
        for child in expand(problem, node):
            stats.generated += 1
            if child.state not in reached:
                reached[child.state] = child.path_cost
                counter += 1
                heapq.heappush(heap, (child.path_cost, counter, child))
            elif child.path_cost < reached[child.state]:
                reopenings.append((child.state, reached[child.state], child.path_cost))
            stats.max_frontier = max(stats.max_frontier, len(heap))
            stats.max_reached = max(stats.max_reached, len(reached))
    return None, stats.as_dict(), reopenings


def dfs(problem: Any, reverse: bool = False) -> tuple[Optional[Node], dict[str, int]]:
    """Run DFS tree search with current-path cycle checking."""
    root = Node(problem.initial_state())
    stats = Stats(generated=1, max_frontier=1)
    frontier_size = 1

    def visit(node: Node, path_states: set[Any]) -> Optional[Node]:
        nonlocal frontier_size
        frontier_size -= 1
        if problem.goal_test(node.state):
            return node
        stats.expanded += 1
        children = list(expand(problem, node))
        if reverse:
            children.reverse()
        valid_children: list[Node] = []
        for child in children:
            stats.generated += 1
            if child.state in path_states:
                continue
            valid_children.append(child)
        frontier_size += len(valid_children)
        stats.max_frontier = max(stats.max_frontier, frontier_size)
        for child in valid_children:
            result = visit(child, path_states | {child.state})
            if result is not None:
                return result
        return None

    result = visit(root, {root.state})
    return result, stats.as_dict()

def dls(problem: Any, limit: int, reverse: bool = False, shared_reached: bool = False) -> tuple[Any, dict[str, int]]:
    """Run depth-limited tree search, returning a Node, cutoff, or failure."""
    stats = Stats(generated=1, max_frontier=1)
    root = Node(problem.initial_state())
    shared: set[Any] = set()
    frontier_size = 1

    def visit(node: Node, path_states: set[Any]) -> Any:
        nonlocal frontier_size
        frontier_size -= 1
        if problem.goal_test(node.state):
            return node
        if node.depth == limit:
            return "cutoff"
        stats.expanded += 1
        children = list(expand(problem, node))
        if reverse:
            children.reverse()
        valid_children: list[Node] = []
        for child in children:
            stats.generated += 1
            if shared_reached:
                if child.state in shared:
                    continue
                shared.add(child.state)
                valid_children.append(child)
            else:
                if child.state in path_states:
                    continue
                valid_children.append(child)
        frontier_size += len(valid_children)
        stats.max_frontier = max(stats.max_frontier, frontier_size)
        saw_cutoff = False
        for child in valid_children:
            result = visit(child, path_states | {child.state})
            if isinstance(result, Node):
                return result
            if result == "cutoff":
                saw_cutoff = True
        return "cutoff" if saw_cutoff else "failure"

    if shared_reached:
        shared.add(root.state)
    result = visit(root, {root.state})
    stats.max_frontier = max(stats.max_frontier, frontier_size)
    return result, stats.as_dict()

def ids(problem: Any, max_limit: int = 100, reverse: bool = False) -> tuple[Optional[Node], list[dict[str, Any]], dict[str, int]]:
    """Run iterative deepening search using repeated correct DLS iterations."""
    iterations: list[dict[str, Any]] = []
    total = Stats()
    for limit in range(max_limit + 1):
        result, stats = dls(problem, limit, reverse=reverse, shared_reached=False)
        total.generated += stats["nodes_generated"]
        total.expanded += stats["nodes_expanded"]
        total.max_frontier = max(total.max_frontier, stats["max_frontier_size"])
        total.max_reached = 0
        value = "solution" if isinstance(result, Node) else result
        iterations.append({"limit": limit, **stats, "return": value})
        if isinstance(result, Node):
            return result, iterations, total.as_dict()
        if result == "failure":
            return None, iterations, total.as_dict()
    return None, iterations, total.as_dict()


def bidirectional_bfs(problem: Any) -> tuple[Optional[int], dict[str, Any]]:
    """Run layer-synchronous bidirectional BFS for a reversible state space."""
    start = problem.initial_state()
    goal = problem.goal_state
    if problem.goal_test(start):
        return 0, {"nodes_generated": 1, "intersections": [start]}

    frontier_f = {start}
    frontier_b = {goal}
    reached_f = {start: 0}
    reached_b = {goal: 0}
    generated = 2
    intersections: list[Any] = []

    while frontier_f and frontier_b:
        if len(frontier_f) <= len(frontier_b):
            current = frontier_f
            next_frontier: set[Any] = set()
            for state in current:
                for action in problem.actions(state):
                    nxt = problem.result(state, action)
                    if nxt not in reached_f:
                        reached_f[nxt] = reached_f[state] + 1
                        generated += 1
                        next_frontier.add(nxt)
                        if nxt in reached_b:
                            intersections.append(nxt)
            frontier_f = next_frontier
            direction = "forward"
        else:
            current = frontier_b
            next_frontier = set()
            for state in current:
                for action in problem.actions(state):
                    nxt = problem.result(state, action)
                    if nxt not in reached_b:
                        reached_b[nxt] = reached_b[state] + 1
                        generated += 1
                        next_frontier.add(nxt)
                        if nxt in reached_f:
                            intersections.append(nxt)
            frontier_b = next_frontier
            direction = "backward"

        if intersections:
            best = min(reached_f[m] + reached_b[m] for m in intersections)
            return best, {
                "nodes_generated": generated,
                "intersections": intersections,
                "reached_forward": len(reached_f),
                "reached_backward": len(reached_b),
                "last_direction": direction,
            }

    return None, {
        "nodes_generated": generated,
        "intersections": intersections,
        "reached_forward": len(reached_f),
        "reached_backward": len(reached_b),
        "last_direction": None,
    }
