"""Assignment problem formulations for the water-jug and weighted graph examples."""

from __future__ import annotations

from collections import defaultdict, deque
from typing import Any

from .core import Problem


class WaterJugProblem(Problem):
    """Five-litre/three-litre ungraduated jug formulation from Problem 1."""

    capacity5 = 5
    capacity3 = 3

    def initial_state(self) -> tuple[int, int]:
        """Return the initial empty-jugs state."""
        return (0, 0)

    def actions(self, state: tuple[int, int]) -> list[str]:
        """Return only actions that actually change the current state."""
        x, y = state
        actions: list[str] = []
        candidates = [
            ("Fill5", (5, y)),
            ("Empty5", (0, y)),
            ("Fill3", (x, 3)),
            ("Empty3", (x, 0)),
        ]
        t53 = min(x, 3 - y)
        candidates.append(("Pour5to3", (x - t53, y + t53)))
        t35 = min(y, 5 - x)
        candidates.append(("Pour3to5", (x + t35, y - t35)))
        for action, result in candidates:
            if result != state:
                actions.append(action)
        return actions

    def result(self, state: tuple[int, int], action: str) -> tuple[int, int]:
        """Return the result of the named jug action."""
        x, y = state
        if action == "Fill5":
            return (5, y)
        if action == "Empty5":
            return (0, y)
        if action == "Fill3":
            return (x, 3)
        if action == "Empty3":
            return (x, 0)
        if action == "Pour5to3":
            t = min(x, 3 - y)
            return (x - t, y + t)
        if action == "Pour3to5":
            t = min(y, 5 - x)
            return (x + t, y - t)
        raise ValueError(f"Unknown action: {action}")

    def goal_test(self, state: tuple[int, int]) -> bool:
        """Return True for states with exactly four litres in the five-litre jug."""
        return state[0] == 4


class WeightedGraphProblem(Problem):
    """Undirected weighted graph from Problem 2."""

    EDGES = {
        "S": [("A", 2), ("B", 5), ("C", 4)],
        "A": [("D", 9), ("E", 4), ("S", 2)],
        "B": [("E", 1), ("F", 7), ("S", 5)],
        "C": [("F", 2), ("S", 4)],
        "D": [("A", 9), ("G", 3)],
        "E": [("A", 4), ("B", 1), ("G", 8)],
        "F": [("B", 7), ("C", 2), ("G", 6)],
        "G": [("D", 3), ("E", 8), ("F", 6)],
    }

    def __init__(self, start: str = "S", goal: str = "G", reverse: bool = False) -> None:
        """Create the weighted graph problem with optional reverse-alphabetical ordering."""
        self.start = start
        self.goal = goal
        self.reverse = reverse

    def initial_state(self) -> str:
        """Return the start node."""
        return self.start

    def actions(self, state: str) -> list[str]:
        """Return neighboring node labels in alphabetical order."""
        neighbors = [v for v, _ in self.EDGES[state]]
        neighbors.sort(reverse=self.reverse)
        return neighbors

    def result(self, state: str, action: str) -> str:
        """Return the neighboring node reached by the action."""
        return action

    def goal_test(self, state: str) -> bool:
        """Return True at node G."""
        return state == self.goal

    def step_cost(self, state: str, action: str, next_state: str) -> float:
        """Return the edge weight for a graph transition."""
        for neighbor, cost in self.EDGES[state]:
            if neighbor == next_state:
                return float(cost)
        raise ValueError("Edge not found")


def reachable_water_jug_states() -> set[tuple[int, int]]:
    """Return all water-jug states reachable from (0, 0)."""
    problem = WaterJugProblem()
    reached = {problem.initial_state()}
    queue = deque([problem.initial_state()])
    while queue:
        state = queue.popleft()
        for action in problem.actions(state):
            nxt = problem.result(state, action)
            if nxt not in reached:
                reached.add(nxt)
                queue.append(nxt)
    return reached
