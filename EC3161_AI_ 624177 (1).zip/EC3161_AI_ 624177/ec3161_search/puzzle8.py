"""8-puzzle problem definition and deterministic utilities."""

from __future__ import annotations

from collections import deque
from typing import Iterable

from .core import Problem


MOVE_ORDER = ("Up", "Down", "Left", "Right")
GOAL_STATE = (1, 2, 3, 4, 5, 6, 7, 8, 0)


class Puzzle8(Problem):
    """Eight-puzzle problem using the fixed move order Up, Down, Left, Right."""

    goal_state = GOAL_STATE

    def __init__(self, start: tuple[int, ...]) -> None:
        """Create a puzzle problem from a 9-tuple state."""
        if len(start) != 9 or set(start) != set(range(9)):
            raise ValueError("8-puzzle states must be permutations of 0..8")
        self.start = tuple(start)
        self.goal_state = GOAL_STATE

    def initial_state(self) -> tuple[int, ...]:
        """Return the initial puzzle state."""
        return self.start

    def actions(self, state: tuple[int, ...]) -> list[str]:
        """Return legal blank moves in Up, Down, Left, Right order."""
        blank = state.index(0)
        r, c = divmod(blank, 3)
        legal: list[str] = []
        if r > 0:
            legal.append("Up")
        if r < 2:
            legal.append("Down")
        if c > 0:
            legal.append("Left")
        if c < 2:
            legal.append("Right")
        return legal

    def result(self, state: tuple[int, ...], action: str) -> tuple[int, ...]:
        """Return the state produced by moving the blank in the requested direction."""
        blank = state.index(0)
        delta = {"Up": -3, "Down": 3, "Left": -1, "Right": 1}
        if action not in self.actions(state):
            raise ValueError(f"Illegal action {action}")
        target = blank + delta[action]
        values = list(state)
        values[blank], values[target] = values[target], values[blank]
        return tuple(values)

    def goal_test(self, state: tuple[int, ...]) -> bool:
        """Return True exactly for the canonical goal state."""
        return state == self.goal_state


def random_walk_from_goal(depth: int, seed: int = 20260912) -> tuple[int, ...]:
    """Generate a solvable puzzle by deterministic random legal moves from the goal."""
    import numpy as np

    rng = np.random.default_rng(seed + depth)
    state = GOAL_STATE
    problem = Puzzle8(state)
    previous = None
    for _ in range(depth):
        choices = problem.actions(state)
        if previous is not None:
            opposite = {"Up": "Down", "Down": "Up", "Left": "Right", "Right": "Left"}[previous]
            filtered = [a for a in choices if a != opposite]
            if filtered:
                choices = filtered
        action = choices[int(rng.integers(0, len(choices)))]
        state = problem.result(state, action)
        previous = action
        problem = Puzzle8(state)
    return state


def manhattan_distance(state: tuple[int, ...]) -> int:
    """Return the sum of Manhattan distances of all numbered tiles."""
    total = 0
    for idx, tile in enumerate(state):
        if tile == 0:
            continue
        goal_idx = tile - 1
        r1, c1 = divmod(idx, 3)
        r2, c2 = divmod(goal_idx, 3)
        total += abs(r1 - r2) + abs(c1 - c2)
    return total


def optimal_depth(start: tuple[int, ...]) -> int:
    """Verify the optimal depth of a puzzle state using BFS."""
    problem = Puzzle8(start)
    queue = deque([(start, 0)])
    reached = {start}
    while queue:
        state, depth = queue.popleft()
        if problem.goal_test(state):
            return depth
        for action in problem.actions(state):
            nxt = problem.result(state, action)
            if nxt not in reached:
                reached.add(nxt)
                queue.append((nxt, depth + 1))
    raise RuntimeError("Puzzle state is unreachable")
