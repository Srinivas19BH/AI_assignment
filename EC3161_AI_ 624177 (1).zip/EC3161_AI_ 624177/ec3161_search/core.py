"""Reusable problem and node abstractions for EC-3161 Assignment 2."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable, Optional


@dataclass
class Node:
    """Search-tree node containing a state, parent, action, path cost, and depth."""

    state: Any
    parent: Optional["Node"] = None
    action: Any = None
    path_cost: float = 0.0
    depth: int = 0

    def solution(self) -> list[Any]:
        """Return the sequence of actions from the root to this node."""
        actions: list[Any] = []
        node: Optional[Node] = self
        while node is not None and node.parent is not None:
            actions.append(node.action)
            node = node.parent
        actions.reverse()
        return actions

    def path(self) -> list["Node"]:
        """Return the root-to-node sequence of nodes."""
        nodes: list[Node] = []
        node: Optional[Node] = self
        while node is not None:
            nodes.append(node)
            node = node.parent
        nodes.reverse()
        return nodes


def expand(problem: Any, node: Node) -> Iterable[Node]:
    """Yield child nodes by applying every applicable action in problem order."""
    for action in problem.actions(node.state):
        child_state = problem.result(node.state, action)
        child_cost = node.path_cost + problem.step_cost(node.state, action, child_state)
        yield Node(
            state=child_state,
            parent=node,
            action=action,
            path_cost=child_cost,
            depth=node.depth + 1,
        )


class Problem:
    """Interface required by all reusable search algorithms."""

    def initial_state(self) -> Any:
        """Return the initial state."""
        raise NotImplementedError

    def actions(self, state: Any) -> list[Any]:
        """Return applicable actions in deterministic generation order."""
        raise NotImplementedError

    def result(self, state: Any, action: Any) -> Any:
        """Return the successor state produced by an action."""
        raise NotImplementedError

    def goal_test(self, state: Any) -> bool:
        """Return True exactly when state satisfies the goal condition."""
        raise NotImplementedError

    def step_cost(self, state: Any, action: Any, next_state: Any) -> float:
        """Return the nonnegative step cost of an action."""
        return 1.0
