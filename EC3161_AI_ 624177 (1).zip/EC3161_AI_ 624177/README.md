# EC-3161 Assignment 2 - Problem Formulation and Uninformed Search

**Roll No.: 624151**  
**Author: Mohammad Sohel**  
**Institute: National Institute of Technology, Andhra Pradesh**

This repository implements the reusable uninformed-search library and experiments required for EC-3161 Assignment 2. It follows the conventions C1-C4 in the assignment handout.

## Requirements

Python 3.10+ is recommended.

Install dependencies:

```bash
python -m pip install -r requirements.txt
```

The computational code uses **Python, NumPy, and Matplotlib**. Report generation uses ReportLab.

## Reproduce every table and figure

From the repository root:

```bash
python scripts/run_all.py
```

This single command:

1. runs the water-jug formulation calculations;
2. runs BFS/UCS/DFS/DLS/IDS on the weighted graph;
3. runs the complexity calculations;
4. runs the reusable search-library tests and required broken variants;
5. runs BFS/IDS/bidirectional BFS on the three 8-puzzle instances;
6. runs the optional bonus experiments;
7. writes all numerical tables to `data/`;
8. saves every generated figure programmatically to `figures/`; and
9. generates `report/EC3161_A2_624151_Report.pdf`.

To run only the tests:

```bash
python -m unittest discover -s tests -v
```

## Fixed randomness

All random experiments use an explicit fixed seed (`20260912`) and never use an unseeded RNG.

## Restrictions followed

No heuristic function, Greedy Best-First Search, A*, IDA*, or shortest-path library routine is used. BFS, UCS, DFS, DLS, IDS, and bidirectional BFS are implemented directly from the frontier disciplines and the assignment's conventions.

## AI-tool disclosure

AI assistance was used during preparation of this submission. OpenAI ChatGPT was used to help interpret the assignment requirements, structure the repository, draft/inspect parts of the Python implementation and report text, and check calculations. The submitted code and report were executed and verified in the repository, and the author remains responsible for understanding, checking, and explaining the submitted work during any viva. This disclosure is included to comply with the assignment's AI-tool disclosure requirement.

## Repository layout

```text
.
├── .git/
├── README.md
├── requirements.txt
├── ec3161_search/
│   ├── core.py
│   ├── graph_problems.py
│   ├── puzzle8.py
│   └── searches.py
├── scripts/
│   ├── run_all.py
│   ├── make_figures.py
│   └── make_report.py
├── tests/
│   └── test_searches.py
├── data/
├── figures/
└── report/
    └── EC3161_A2_624151_Report.pdf
```
