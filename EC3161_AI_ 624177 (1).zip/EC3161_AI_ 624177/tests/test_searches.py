"""Unit tests for the reusable EC-3161 search library."""

import unittest

from ec3161_search.graph_problems import WeightedGraphProblem, WaterJugProblem, reachable_water_jug_states
from ec3161_search.puzzle8 import Puzzle8
from ec3161_search.searches import bfs, dls, ids, ucs, ucs_broken_no_reopen


class SearchTests(unittest.TestCase):
    """Check the assignment answer checks and key algorithmic invariants."""

    def test_water_jug_reachable_count(self) -> None:
        """Verify the 24-state / 16-reachable-state result."""
        self.assertEqual(len(reachable_water_jug_states()), 16)
        self.assertEqual(6 * 4, 24)

    def test_weighted_graph_bfs_and_ucs(self) -> None:
        """Verify BFS/UCS return costs 14 and 12 respectively."""
        problem = WeightedGraphProblem()
        bfs_node, _ = bfs(problem)
        ucs_node, _ = ucs(problem)
        self.assertIsNotNone(bfs_node)
        self.assertIsNotNone(ucs_node)
        self.assertEqual(bfs_node.path_cost, 14)
        self.assertEqual(ucs_node.path_cost, 12)

    def test_ucs_reopen(self) -> None:
        """Verify exactly one re-opening and the broken cost difference."""
        class P(WeightedGraphProblem):
            EDGES = {
                "S": [("A", 1), ("C", 5)],
                "A": [("S", 1), ("C", 1)],
                "C": [("A", 1), ("S", 5), ("G", 3)],
                "G": [("C", 3)],
            }
        p = P()
        good, _, = ucs(p)
        bad, _, reopens = ucs_broken_no_reopen(p)
        self.assertEqual(good.path_cost, 5)
        self.assertEqual(bad.path_cost, 8)
        self.assertEqual(len(reopens), 1)

    def test_puzzle_depths(self) -> None:
        """Verify the three supplied optimal depths."""
        cases = {
            4: (0, 1, 3, 4, 2, 6, 7, 5, 8),
            8: (0, 4, 3, 2, 1, 5, 7, 8, 6),
            12: (7, 4, 2, 1, 0, 3, 8, 5, 6),
        }
        from ec3161_search.puzzle8 import optimal_depth
        for depth, state in cases.items():
            self.assertEqual(optimal_depth(state), depth)
            p = Puzzle8(state)
            bnode, _ = bfs(p)
            self.assertEqual(bnode.depth, depth)
            inode, _, _ = ids(p, max_limit=depth)
            self.assertEqual(inode.depth, depth)


if __name__ == "__main__":
    unittest.main()
