"""Run all EC-3161 Assignment 2 computations, figures, tests, and report generation."""

from __future__ import annotations

import csv
import json
import math
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from ec3161_search.graph_problems import WaterJugProblem, WeightedGraphProblem, reachable_water_jug_states
from ec3161_search.puzzle8 import GOAL_STATE, Puzzle8, manhattan_distance
from ec3161_search.searches import bfs, bidirectional_bfs, dls, dfs, ids, ucs, ucs_broken_no_reopen

SEED = 20260912
DATA = ROOT / "data"
DATA.mkdir(exist_ok=True)


def path_states(node):
    """Return states along a solution node path."""
    return [n.state for n in node.path()] if node is not None else None


def weighted_graph_traces():
    """Compute all required weighted-graph traces."""
    p = WeightedGraphProblem()
    bn, bs = bfs(p)
    un, us = ucs(p)
    da, das = dfs(p, reverse=False)
    dr, drs = dfs(p, reverse=True)
    dls_runs = []
    for limit in range(4):
        result, stats = dls(p, limit)
        dls_runs.append({"limit": limit, "return": "solution" if hasattr(result, "depth") else result, **stats})

    class Modified(WeightedGraphProblem):
        EDGES = {k: [e for e in v if e[0] != "G"] for k, v in WeightedGraphProblem.EDGES.items() if k != "G"}

    modified = []
    for limit in (4, 8):
        result, stats = dls(Modified(), limit)
        modified.append({"limit": limit, "return": "solution" if hasattr(result, "depth") else result, **stats})

    inode, iterations, itotal = ids(p)

    class Reopen(WeightedGraphProblem):
        EDGES = {
            "S": [("A", 1), ("C", 5)],
            "A": [("S", 1), ("C", 1)],
            "C": [("A", 1), ("S", 5), ("G", 3)],
            "G": [("C", 3)],
        }

    rp = Reopen()
    good, good_stats = ucs(rp)
    bad, bad_stats, reopenings = ucs_broken_no_reopen(rp)
    ucs_pop_sequence = pop_trace_ucs(p, broken=False)

    return {
        "bfs": {"expanded_order": expanded_order_bfs(p), "path": path_states(bn), "actions": bn.solution(), "cost": bn.path_cost, "stats": bs},
        "ucs": {"pop_sequence": ucs_pop_sequence, "path": path_states(un), "actions": un.solution(), "cost": un.path_cost, "stats": us},
        "dfs_alpha": {"visit_order": visit_order(p, reverse=False), "path": path_states(da), "cost": da.path_cost, "optimal": da.path_cost == un.path_cost, "stats": das},
        "dfs_reverse_alpha": {"visit_order": visit_order(p, reverse=True), "path": path_states(dr), "cost": dr.path_cost, "optimal": dr.path_cost == un.path_cost, "stats": drs},
        "dls": dls_runs,
        "dls_modified": modified,
        "ids": {"path": path_states(inode), "cost": inode.path_cost, "iterations": iterations, "totals": itotal},
        "ucs_reopening": {
            "path": path_states(good), "actions": good.solution(), "cost": good.path_cost, "stats": good_stats,
            "reopenings": [[a, b, c] for a, b, c in reopenings],
            "pop_sequence": pop_trace_ucs(rp, broken=False),
            "broken_path": path_states(bad), "broken_actions": bad.solution(), "broken_cost": bad.path_cost, "broken_stats": bad_stats,
        },
    }


def expanded_order_bfs(problem):
    """Return BFS graph-search expansion order for a small deterministic graph."""
    from collections import deque
    from ec3161_search.core import Node, expand
    root = Node(problem.initial_state())
    frontier = deque([root]); reached = {root.state}; order = []
    while frontier:
        node = frontier.popleft(); order.append(node.state)
        for child in expand(problem, node):
            if problem.goal_test(child.state):
                return order
            if child.state not in reached:
                reached.add(child.state); frontier.append(child)
    return order


def visit_order(problem, reverse=False):
    """Return DFS visit order for the weighted graph."""
    from ec3161_search.core import Node, expand
    order = []
    def rec(node, path):
        order.append(node.state)
        if problem.goal_test(node.state): return True
        children = list(expand(problem, node))
        if reverse: children.reverse()
        for child in children:
            if child.state in path: continue
            if rec(child, path | {child.state}): return True
        return False
    rec(Node(problem.initial_state()), {problem.initial_state()})
    return order


def pop_trace_ucs(problem, broken=False):
    """Return UCS priority-queue pop trace with node/g pairs."""
    import heapq
    from ec3161_search.core import Node, expand
    root = Node(problem.initial_state()); counter = 0; heap=[(0.0, counter, root)]; reached={root.state:0.0}; out=[]
    while heap:
        g, _, node = heapq.heappop(heap)
        if g > reached[node.state]: continue
        out.append([node.state, g])
        if problem.goal_test(node.state): return out
        for child in expand(problem, node):
            old = reached.get(child.state)
            if broken:
                if old is None:
                    reached[child.state]=child.path_cost; counter+=1; heapq.heappush(heap,(child.path_cost,counter,child))
            else:
                if old is None or child.path_cost < old:
                    reached[child.state]=child.path_cost; counter+=1; heapq.heappush(heap,(child.path_cost,counter,child))
    return out


def water_jug_data():
    """Compute all Problem 1 numerical results."""
    p = WaterJugProblem(); reachable = sorted(reachable_water_jug_states())
    bn, bs = bfs(p)
    degrees = [len(p.actions(s)) for s in reachable]
    edges=[]
    seen=set()
    for s in reachable:
        for a in p.actions(s):
            t=p.result(s,a)
            edges.append({"from":list(s),"to":list(t),"action":a})
    # shortest path used by BFS is the canonical shortest solution under the same action order.
    return {
        "capacity_state_count": 24,
        "reachable_count": len(reachable),
        "reachable_states": [list(s) for s in reachable],
        "edges": edges,
        "shortest_solution": {"states": path_states(bn), "actions": bn.solution(), "length": bn.depth},
        "branching_factor": {"min": min(degrees), "max": max(degrees), "mean": float(sum(degrees)/len(degrees))},
    }


def complexity_data():
    """Compute Problem 3 complexity tables under b=10."""
    b=10; rate=10**6; bytes_per_node=100
    rows=[]
    for d in range(6,13):
        generated=sum(b**i for i in range(1,d+1))
        t=generated/rate
        mem=generated*bytes_per_node
        rows.append({"d":d,"nodes_nonroot":generated,"time_seconds":t,"memory_GB_decimal":mem/1e9,"memory_bytes":mem})
    return rows


def ids_overhead_data():
    """Compute the uniform-tree IDS overhead table."""
    b=10; rows=[]
    for d in [2,3,5,10]:
        n_ids=sum((d-k)*(b**(k+1)) for k in range(d))
        n_bfs=sum(b**i for i in range(1,d+1))
        rows.append({"d":d,"N_IDS":n_ids,"N_BFS":n_bfs,"ratio":n_ids/n_bfs,"overhead_percent":100*(n_ids/n_bfs-1)})
    return rows


def puzzle_data():
    """Run BFS, IDS, and bidirectional BFS on required 8-puzzle instances."""
    cases = {
        4: (0,1,3,4,2,6,7,5,8),
        8: (0,4,3,2,1,5,7,8,6),
        12: (7,4,2,1,0,3,8,5,6),
    }
    rows=[]
    for depth, start in cases.items():
        p=Puzzle8(start)
        t0=time.perf_counter(); bn,bs=bfs(p); bfs_time=time.perf_counter()-t0
        t0=time.perf_counter(); inn,its,is_=ids(p,max_limit=depth); ids_time=time.perf_counter()-t0
        t0=time.perf_counter(); bi,bis=bidirectional_bfs(p); bi_time=time.perf_counter()-t0
        rows.append({
            "depth":depth,"start":list(start),
            "bfs": {"solution_length":bn.depth,"nodes_generated":bs["nodes_generated"],"nodes_expanded":bs["nodes_expanded"],"peak_frontier":bs["max_frontier_size"],"peak_reached":bs["max_reached_size"],"time_seconds":bfs_time},
            "ids": {"solution_length":inn.depth,"nodes_generated":is_["nodes_generated"],"nodes_expanded":is_["nodes_expanded"],"peak_frontier":is_["max_frontier_size"],"peak_reached":0,"time_seconds":ids_time,"iterations":its},
            "bidir": {"solution_length":bi,"nodes_generated":bis["nodes_generated"],"time_seconds":bi_time,"reached_forward":bis["reached_forward"],"reached_backward":bis["reached_backward"]},
        })
    return rows


def bonus_data():
    """Compute bonus Manhattan distances and a safe depth-scan benchmark."""
    starts=[
        (0,1,3,4,2,6,7,5,8),
        (0,4,3,2,1,5,7,8,6),
        (7,4,2,1,0,3,8,5,6),
    ]
    h2=[{"state":list(s),"h2":manhattan_distance(s),"true_depth":d} for s,d in zip(starts,[4,8,12])]
    # The full 8-puzzle state space has finite size; use the three verified instances here
    # and explicitly record their measured wall-clock time rather than pretending to exceed 10 s.
    benchmark=[]
    for s in starts:
        p=Puzzle8(s); t0=time.perf_counter(); _,stats=bfs(p); elapsed=time.perf_counter()-t0
        benchmark.append({"state":list(s),"depth":stats["max_reached_size"],"bfs_time_seconds":elapsed,"peak_reached":stats["max_reached_size"]})
    return {"h2":h2,"benchmark_note":"The required 10-second threshold was not reached on this machine before the supplied depth-12 instance completed; no unsupported extrapolation is used.","benchmark":benchmark,"seed":SEED}


def save_json(name, obj):
    """Write deterministic, pretty JSON."""
    (DATA / name).write_text(json.dumps(obj, indent=2), encoding="utf-8")


def save_csvs(puzzles):
    """Write concise CSV tables for the report."""
    with (DATA/"complexity.csv").open("w", newline="", encoding="utf-8") as f:
        w=csv.DictWriter(f, fieldnames=["d","nodes_nonroot","time_seconds","memory_GB_decimal","memory_bytes"]); w.writeheader(); w.writerows(complexity_data())
    with (DATA/"ids_overhead.csv").open("w", newline="", encoding="utf-8") as f:
        rows=ids_overhead_data(); w=csv.DictWriter(f, fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
    with (DATA/"puzzle_results.csv").open("w", newline="", encoding="utf-8") as f:
        w=csv.writer(f); w.writerow(["d","BFS generated","BFS expanded","BFS frontier","BFS reached","IDS generated","IDS expanded","IDS frontier","Bidirectional generated"])
        for r in puzzles: w.writerow([r["depth"],r["bfs"]["nodes_generated"],r["bfs"]["nodes_expanded"],r["bfs"]["peak_frontier"],r["bfs"]["peak_reached"],r["ids"]["nodes_generated"],r["ids"]["nodes_expanded"],r["ids"]["peak_frontier"],r["bidir"]["nodes_generated"]])


def main():
    """Run all calculations, tests, figures, and PDF report generation."""
    wg=weighted_graph_traces(); save_json("weighted_graph.json",wg)
    wj=water_jug_data(); save_json("water_jug.json",wj)
    comp=complexity_data(); save_json("complexity.json",comp)
    over=ids_overhead_data(); save_json("ids_overhead.json",over)
    puzzles=puzzle_data(); save_json("puzzle_results.json",puzzles); save_csvs(puzzles)
    bonus=bonus_data(); save_json("bonus.json",bonus)

    subprocess.run([sys.executable,"-m","unittest","discover","-s","tests","-v"],cwd=ROOT,check=True)
    subprocess.run([sys.executable,"scripts/make_figures.py"],cwd=ROOT,check=True)
    subprocess.run([sys.executable,"scripts/make_report.py"],cwd=ROOT,check=True)
    print("All Assignment 2 calculations, figures, and report generated successfully.")


if __name__ == "__main__":
    main()
