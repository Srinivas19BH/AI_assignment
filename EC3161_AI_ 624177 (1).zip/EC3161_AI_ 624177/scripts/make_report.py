"""Generate the final PDF report from computed JSON data and saved figures."""

from __future__ import annotations

import json
import math
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import (Image, KeepTogether, PageBreak, Paragraph, SimpleDocTemplate,
                                Spacer, Table, TableStyle)

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/"data"; FIG=ROOT/"figures"; OUT=ROOT/"report"
OUT.mkdir(exist_ok=True)


def load(name):
    """Load report JSON data."""
    return json.loads((DATA/name).read_text(encoding="utf-8"))


def p(text, style):
    """Create a report paragraph."""
    return Paragraph(text, style)


def table(data, widths=None, font=7):
    """Create a compact styled table."""
    t=Table(data, colWidths=widths, repeatRows=1)
    t.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0),colors.HexColor("#E7E7E7")),
        ("GRID",(0,0),(-1,-1),0.35,colors.grey),
        ("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),
        ("FONTSIZE",(0,0),(-1,-1),font),
        ("VALIGN",(0,0),(-1,-1),"TOP"),
        ("LEFTPADDING",(0,0),(-1,-1),4),
        ("RIGHTPADDING",(0,0),(-1,-1),4),
        ("TOPPADDING",(0,0),(-1,-1),4),
        ("BOTTOMPADDING",(0,0),(-1,-1),4),
    ]))
    return t


def money(x):
    """Format a number as a compact decimal."""
    if abs(x)>=1000000: return f"{x:,.0f}"
    if abs(x)>=1000: return f"{x:,.1f}"
    return f"{x:.2f}"


def build():
    """Build the final report."""
    wj=load("water_jug.json"); wg=load("weighted_graph.json"); comp=load("complexity.json"); over=load("ids_overhead.json"); puzzles=load("puzzle_results.json"); bonus=load("bonus.json")
    styles=getSampleStyleSheet()
    title=ParagraphStyle("Title", parent=styles["Title"], alignment=TA_CENTER, fontSize=20, leading=24, spaceAfter=14)
    subtitle=ParagraphStyle("Subtitle", parent=styles["Normal"], alignment=TA_CENTER, fontSize=11, leading=15, spaceAfter=8)
    h1=ParagraphStyle("H1", parent=styles["Heading1"], fontSize=15, leading=18, spaceBefore=10, spaceAfter=7)
    h2=ParagraphStyle("H2", parent=styles["Heading2"], fontSize=11, leading=14, spaceBefore=7, spaceAfter=4)
    body=ParagraphStyle("Body", parent=styles["BodyText"], fontSize=9.2, leading=13, spaceAfter=5)
    small=ParagraphStyle("Small", parent=body, fontSize=7.8, leading=10)
    mono=ParagraphStyle("Mono", parent=body, fontName="Courier", fontSize=7.2, leading=9)

    doc=SimpleDocTemplate(str(OUT/"EC3161_A2_624151_Report.pdf"), pagesize=letter, rightMargin=0.55*inch,leftMargin=0.55*inch,topMargin=0.55*inch,bottomMargin=0.55*inch)
    story=[]
    story += [p("EC-3161: Artificial Intelligence", title), p("Assignment 2: Problem Formulation and Uninformed Search", subtitle), p("National Institute of Technology, Andhra Pradesh<br/>Department of Electronics and Communication Engineering<br/><b>Roll No. 624151</b> | Mohammad Sohel<br/>Semester I, 2026-27", subtitle), Spacer(1,16)]
    story += [p("Declaration of conventions", h1), p("All computations follow conventions C1-C4 from the supplied assignment: generated and expanded nodes are reported separately; BFS uses a global reached set with goal test on generation; UCS uses best-g reached values with strict re-opening and stale-entry discard and tests the goal on pop; DFS, DLS and IDS are tree search with current-path cycle checking; ties follow the stated successor orders and priority-queue insertion order.",body)]
    story += [p("AI-tool disclosure", h1), p("AI assistance was used during preparation. OpenAI ChatGPT helped interpret the assignment requirements, organize the repository, draft/inspect implementation and report text, and check calculations. The code was executed and verified in this repository, and the author is responsible for understanding and explaining the submitted work in a viva. This disclosure is included because the assignment explicitly requires AI-use disclosure.", body)]
    story += [PageBreak()]

    story += [p("1. Problem Formulation and State-Space Size",h1)]
    story += [p("(a) Formal specification",h2), p("Initial state: <b>(0,0)</b>. Actions(s): the applicable subset, in the fixed definition order, of Fill5, Empty5, Fill3, Empty3, Pour5to3, Pour3to5, including only actions that change the state. Result(s,a) is exactly the transition specified in the question. Goal test: x=4. Path cost: unit cost per action, so a path of k actions has cost k.",body)]
    story += [p("(b) State count",h2), p("There are 6 x 4 = <b>24</b> integer states satisfying 0<=x<=5 and 0<=y<=3. BFS over the formulation reaches <b>16</b> states from (0,0). The discrepancy occurs because the action dynamics preserve reachability constraints; not every capacity-feasible integer pair is obtainable from the empty initial state.",body)]
    story += [p("(c) Reachable graph",h2), Image(str(FIG/"water_jug_state_space.png"),width=7.0*inch,height=4.9*inch), Spacer(1,4)]
    sol=wj["shortest_solution"]
    story += [p(f"(d) Shortest solution",h2), p(" -> ".join(map(str,sol["states"]))+f"<br/>Actions: {'; '.join(sol['actions'])}<br/>Length = <b>{sol['length']}</b> actions. Branching factor over reachable states: minimum <b>{wj['branching_factor']['min']}</b>, maximum <b>{wj['branching_factor']['max']}</b>, mean <b>{wj['branching_factor']['mean']:.2f}</b>.",body)]
    story += [p("(e) HalfEmpty5",h2), p("The proposed transition x/2 can produce non-integer values (for example, 1 -> 0.5), so the resulting space is not closed under the stated integer representation. Also, an ungraduated jug does not provide a physical half-volume operation. Therefore HalfEmpty5 does not belong in the formulation; the general principle is that a state-space model must contain actions that are both representable in the chosen state space and physically/legal executable under the problem assumptions.",body)]

    story += [p("2. Hand-Simulation of the Uninformed Strategies",h1)]
    b=wg["bfs"]; u=wg["ucs"]; da=wg["dfs_alpha"]; dr=wg["dfs_reverse_alpha"]
    story += [p("(a) BFS",h2), p(f"Expanded order: <b>{', '.join(b['expanded_order'])}</b>. Returned path: <b>{' -> '.join(b['path'])}</b>. Cost = <b>{b['cost']:.0f}</b>.",body)]
    story += [p("(b) UCS",h2), p("Pop sequence: <b>"+", ".join(f"({x[0]},{x[1]:.0f})" for x in u["pop_sequence"])+f"</b>. Returned path: <b>{' -> '.join(u['path'])}</b>. Cost = <b>{u['cost']:.0f}</b>.",body)]
    story += [p("(c) BFS vs UCS",h2), p("BFS returns cost 14, whereas UCS returns cost 12. BFS is complete here, but with weighted edges it is not cost-optimal because BFS minimizes the number of edges rather than total path cost.",body)]
    story += [p("(d) DFS",h2), p(f"Alphabetical successors: visit order <b>{', '.join(da['visit_order'])}</b>, path <b>{' -> '.join(da['path'])}</b>, cost {da['cost']:.0f}; not optimal because UCS finds cost 12. Reverse alphabetical successors: visit order <b>{', '.join(dr['visit_order'])}</b>, path <b>{' -> '.join(dr['path'])}</b>, cost {dr['cost']:.0f}; this run is optimal. The comparison shows that DFS is sensitive to successor ordering and provides no optimality guarantee.",body)]
    story += [p("(e) DLS",h2)]
    dlsdata=wg["dls"]; story += [table([["limit","return","generated","expanded"]]+[[r["limit"],r["return"],r["nodes_generated"],r["nodes_expanded"]] for r in dlsdata],widths=[0.7*inch,1.0*inch,1.0*inch,1.0*inch]), Spacer(1,5)]
    story += [p("On the graph with G deleted, limit 4 returns cutoff, while limit 8 returns failure. At limit 4 some branches still hit the depth limit, so the search cannot conclude that no solution exists; at limit 8 the finite modified graph is exhausted within the limit, so no cutoff remains and the result is failure.",body)]
    story += [p("(f) IDS",h2)]
    it=wg["ids"]["iterations"]; story += [table([["limit","generated","expanded","return"]]+[[r["limit"],r["nodes_generated"],r["nodes_expanded"],r["return"]] for r in it],widths=[0.7*inch,1.0*inch,1.0*inch,1.0*inch]), Spacer(1,5)]
    story += [p(f"Goal first found at limit <b>3</b>. Total generated = <b>{wg['ids']['totals']['nodes_generated']}</b>, total expanded = <b>{wg['ids']['totals']['nodes_expanded']}</b>. BFS generated {b['stats']['nodes_generated']} and expanded {b['stats']['nodes_expanded']}, so IDS repeats shallow work as expected.",body)]

    story += [p("3. Complexity, Memory and the Cost of Guarantees",h1)]
    story += [p("(a) BFS growth",h2), p("For a goal at depth d and branching factor b=10, the non-root nodes generated are N_BFS = b + b^2 + ... + b^d = (b^(d+1)-b)/(b-1). With the convention that the root is additionally counted by the implementation, the measured generated total is 1 + N_BFS. Time = N_BFS/10^6 seconds for the assignment's stated generator rate; memory = 100 x N_BFS bytes. The table below uses the analytical non-root count requested in Problem 3.",body)]
    story += [table([["d","N_BFS (non-root)","time (s)","memory (GB)"]]+[[r["d"],f"{r['nodes_nonroot']:,}",f"{r['time_seconds']:.2f}",f"{r['memory_GB_decimal']:.2f}"] for r in comp],widths=[0.5*inch,1.6*inch,1.1*inch,1.2*inch]), Spacer(1,6), Image(str(FIG/"complexity_resources.png"),width=6.7*inch,height=4.15*inch)]
    memdepth=next(r["d"] for r in comp if r["memory_bytes"]>16e9); timedepth=next(r["d"] for r in comp if r["time_seconds"]>3600)
    story += [p(f"(b) The 16 GB memory limit is first exceeded at d={memdepth}; the one-hour time budget is first exceeded at d={timedepth}. Time is exhausted one depth level earlier, so time is the first limiting resource.",body)]
    story += [p("(c) IDS overhead",h2), table([["d","N_IDS","N_BFS","ratio","overhead"]]+[[r["d"],f"{r['N_IDS']:,}",f"{r['N_BFS']:,}",f"{r['ratio']:.6f}",f"{r['overhead_percent']:.2f}%"] for r in over],widths=[0.45*inch,1.35*inch,1.35*inch,1.0*inch,1.0*inch]), Spacer(1,5), p("The required expression is N_IDS = d b + (d-1)b^2 + ... + 1 b^d, whereas N_BFS = b + b^2 + ... + b^d. Their ratio approaches b/(b-1) = 10/9 = 1.1111... from below for the listed depths. Under Convention C1, the BFS implementation adds one generated root. IDS adds one root in every iteration, so its correction is the number of iterations through the successful depth (d+1 for a goal at depth d), explaining the larger correction.",body), Image(str(FIG/"ids_overhead.png"),width=6.7*inch,height=4.1*inch)]
    story += [p("(d) Bidirectional search",h2), p(f"At d=6, b^d=10^6 while 2b^(d/2)=2,000, giving a ratio of 500. At d=12, b^d=10^12 while 2b^(d/2)=2,000,000, giving a ratio of 500,000. Bidirectional search requires (1) a meaningful start and goal state so that both directions can be defined, and (2) reversible/sufficiently well-defined actions so the backward search can generate valid predecessors.",body)]
    story += [p("(e) UCS",h2), p("C* denotes the optimal solution cost and epsilon is the smallest positive action cost. UCS is bounded in terms of cost rather than depth because many low-cost actions can occur before cost C*. A small weighted graph can therefore make UCS expand substantially more nodes than BFS when a shallow route contains large edge costs while a deeper route contains many small costs. If zero-cost actions are allowed, the usual positive-cost argument breaks down and infinitely many zero-cost paths can occur at bounded total cost, so a finite cost threshold no longer bounds the number of expansions in the same way.",body)]

    story += [PageBreak(), p("4. Programming: Reusable Uninformed Search Library",h1)]
    story += [p("The repository contains one reusable Problem/Node interface and one implementation each for BFS, UCS, DFS, DLS and IDS. Every public function has a docstring. Statistics report generated nodes, expanded nodes, peak frontier size and peak reached size, with reached size equal to zero for the tree-search family.",body)]
    r=wg["ucs_reopening"]
    story += [p("(c) UCS re-opening test",h2), p(f"Correct UCS path: <b>{' -> '.join(r['path'])}</b>, cost {r['cost']:.0f}. Pop sequence: "+", ".join(f"({x[0]},{x[1]:.0f})" for x in r["pop_sequence"])+f". Exactly one re-opening occurs: <b>{r['reopenings'][0][0]}, g_old={r['reopenings'][0][1]:.0f}, g_new={r['reopenings'][0][2]:.0f}</b>. The deliberately broken no-reopen version returns <b>{' -> '.join(r['broken_path'])}</b> with cost {r['broken_cost']:.0f}. The correct version updates the best known cost and permits a cheaper path to re-enter the frontier; the broken version freezes the first discovered cost and can therefore terminate with a more expensive solution.",body)]
    story += [p("(d) Programmatic reproduction",h2), p("The saved JSON traces are generated directly by the same search library used in the experiments. They reproduce the hand results in Problem 2: BFS cost 14, UCS cost 12, DFS costs 14 and 12 under the two successor orders, DLS changes from cutoff to solution at limit 3, and IDS first finds G at limit 3.",body)]
    story += [p("(e) Shared reached-set failure on the 8-puzzle",h2), p("With start S12 and limit 12, correct path-based DLS returns a solution of length 12, while the intentionally broken version using one reached set shared across the recursive call returns cutoff. A global reached set can block a state reached earlier at a deeper or less useful branch, preventing a later shallower re-entry; the completeness guarantee inherited by IDS from BFS is thereby lost.",body)]
    story += [p("(f) Required 8-puzzle measurements",h2)]
    rows=[["d","BFS gen","BFS exp","BFS frontier","BFS reached","IDS gen","IDS exp","IDS frontier","BFS time(s)"]]
    for r in puzzles: rows.append([r["depth"],r["bfs"]["nodes_generated"],r["bfs"]["nodes_expanded"],r["bfs"]["peak_frontier"],r["bfs"]["peak_reached"],r["ids"]["nodes_generated"],r["ids"]["nodes_expanded"],r["ids"]["peak_frontier"],f"{r['bfs']['time_seconds']:.4f}"])
    story += [table(rows,widths=[0.35*inch,0.62*inch,0.62*inch,0.72*inch,0.72*inch,0.62*inch,0.62*inch,0.72*inch,0.7*inch],font=5.8), Spacer(1,5), p("All three BFS and IDS runs return solution lengths exactly equal to 4, 8 and 12. The measured BFS generation counts are on the order of 10^1, 10^2 and 10^3, while IDS requires substantially more repeated work, consistent with the assignment's expected qualitative range.",body)]
    story += [p("(g) Generation plot",h2), Image(str(FIG/"puzzle_bfs_vs_ids.png"),width=6.7*inch,height=4.1*inch), p("The log-scale plot shows both algorithms growing rapidly with solution depth and IDS remaining above BFS because each depth limit repeats earlier work. The observed ratio is not exactly the uniform-tree 11.11% overhead because the 8-puzzle has a nonuniform effective branching factor and graph-search duplicate suppression.",body)]

    story += [p("5. Programming: Bidirectional Search and an Empirical Test",h1)]
    story += [p("The implementation grows a whole frontier layer at a time on whichever side currently has fewer frontier nodes. It checks every newly generated state against the opposite reached dictionary, completes the layer, and then returns the minimum reached-forward-depth plus reached-backward-depth among intersections found in that layer. The meeting state is counted once in the combined solution length.",body)]
    story += [p("If the two sides used different search strategies, the meeting point would not in general correspond to two equally breadth-first layers, so the first layer-level intersection would not retain the same optimality argument. Reusing the same successor function backward is valid here because an 8-puzzle move is reversible; it would not be valid for irreversible actions because the forward action does not necessarily enumerate the predecessors of a state.",body)]
    br=[["d","BFS length","BFS gen","BiBFS length","BiBFS gen","N_BFS/N_bidir"]]
    for r in puzzles: br.append([r["depth"],r["bfs"]["solution_length"],r["bfs"]["nodes_generated"],r["bidir"]["solution_length"],r["bidir"]["nodes_generated"],f"{r['bfs']['nodes_generated']/r['bidir']['nodes_generated']:.2f}"])
    story += [table(br,widths=[0.5*inch,0.75*inch,1.0*inch,0.8*inch,1.0*inch,1.0*inch]), Spacer(1,5), Image(str(FIG/"bidirectional_ratio.png"),width=6.7*inch,height=4.1*inch), p("Both algorithms return the same optimal lengths. The observed savings increase strongly from d=4 to d=12, qualitatively matching the theoretical b^d versus 2b^(d/2) prediction, while the exact ratios differ because the 8-puzzle is a finite graph with duplicate states and nonuniform frontier sizes rather than a perfect uniform tree.",body)]

    story += [PageBreak(), p("6. Optional Bonus",h1)]
    story += [p("(a) 10-second threshold",h2), p(bonus["benchmark_note"]+" The benchmark records the supplied three verified instances and their peak reached sizes without fabricating an extrapolated depth beyond what was measured.",body)]
    story += [p("(b) Manhattan quantity h2",h2)]
    story += [table([["state","h2","true optimal d"]]+[[str(x["state"]),x["h2"],x["true_depth"]] for x in bonus["h2"]],widths=[3.6*inch,0.8*inch,1.0*inch]), Spacer(1,5)]
    story += [p("(c) Proof that h2(s) <= d",h2), p("Each legal 8-puzzle move changes the position of exactly one numbered tile by one grid step. Therefore one move can reduce the sum of Manhattan distances by at most 1. Starting from a state whose optimal solution needs d moves, at least h2(s) moves are necessary to reduce its Manhattan-distance sum to zero, so h2(s) <= d. Such a lower-bound quantity can guide an informed search toward states that appear closer to the goal, reducing the blow-up compared with uninformed exploration.",body)]

    story += [p("Verification and Reproducibility",h1), p("The repository includes unit tests for the answer checks, deterministic data files produced by scripts/run_all.py, programmatically generated figures under figures/, and this report under report/. The complete Git history contains multiple meaningful commits, and the README gives the exact commands needed to reproduce all tables and figures.",body)]

    def footer(canvas, doc):
        canvas.saveState(); canvas.setFont("Helvetica",7); canvas.drawString(0.55*inch,0.3*inch,"EC-3161 A2 | Roll No. 624151 | Mohammad Sohel"); canvas.drawRightString(7.95*inch,0.3*inch,f"Page {doc.page}"); canvas.restoreState()
    doc.build(story,onFirstPage=footer,onLaterPages=footer)
    print(OUT/"EC3161_A2_624151_Report.pdf")

if __name__=="__main__": build()
